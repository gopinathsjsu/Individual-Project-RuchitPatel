package Flighthelper;



import FlightModels.Flight;
import com.fasterxml.jackson.core.FormatSchema;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.MappingIterator;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.csv.CsvMapper;
import com.fasterxml.jackson.dataformat.csv.CsvSchema;
import java.io.*;
import java.util.*;

import com.google.gson.*;




public class ReadCSVintoJSON {
    public static  List<Map<?,?>> readCsvToJson(String csvFile){
        File read = new File(csvFile);
        //this list hold each record in CSV file as a key value pair with header as key and value as values.
        List<Map<?,?>> flights = new ArrayList<>();
        try {
            CsvSchema csv = CsvSchema.emptySchema().withHeader();
            CsvMapper csvMapper = new CsvMapper();
            MappingIterator<Map<?,?>> mappingIterator =  csvMapper.reader().forType(Map.class).with(csv).readValues(read);
            System.out.println();
            while(mappingIterator.hasNext()){
                flights.add(mappingIterator.next());
            }
        } catch(Exception e) {
            e.printStackTrace();
        }

        return flights;
    }


 }
