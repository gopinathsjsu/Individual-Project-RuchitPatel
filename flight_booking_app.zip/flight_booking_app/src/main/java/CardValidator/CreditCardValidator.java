package CardValidator;

import FlightModels.InputFile;

public abstract class CreditCardValidator {
    public CreditCardValidator nextCardValidator;

    public void SetCreditCardValidator(CreditCardValidator nextCardValidator) {
        this.nextCardValidator = nextCardValidator;
    }

    public abstract boolean isValidCard(String cardNumber);

}
