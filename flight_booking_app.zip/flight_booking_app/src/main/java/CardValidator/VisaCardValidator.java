package CardValidator;



public class VisaCardValidator extends CreditCardValidator {



    @Override
    public boolean isValidCard(String cardNumber) {
        String card = cardNumber;
        if ((card.length() == 13 || card.length() == 16) && (card.charAt(0) == '4')) {
            System.out.println("It is a valid visa card");
            return true;
        }
        else if(card.length()>19){
            System.out.println("It is invalid card of length greater than 19");
            return false;
        }
        else {
            return nextCardValidator.isValidCard(cardNumber);
        }
    }



}