package CardValidator;

import FlightModels.InputFile;

public class DiscoverCardvalidator extends CreditCardValidator{


    @Override
    public boolean isValidCard(String cardNumber) {
        String card = cardNumber;
        if (card.length() == 16  && card.startsWith("6011") ) {
            System.out.println("It is a Valid Discover card");
            return true;
        }
        else{
            return nextCardValidator.isValidCard(cardNumber);
        }
    }

}
