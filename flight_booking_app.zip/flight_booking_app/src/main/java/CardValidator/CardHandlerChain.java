package CardValidator;

public class CardHandlerChain {
    public static VisaCardValidator visa = new VisaCardValidator();
    public static  MasterCardValidator master = new MasterCardValidator();
    public static  DiscoverCardvalidator discover = new DiscoverCardvalidator();
    public static  AmexCardValidator amex = new AmexCardValidator();

    static{
       visa.SetCreditCardValidator(master);
       master.SetCreditCardValidator(discover);
       discover.SetCreditCardValidator(amex);
    }

    public boolean cardValidation(String cardNumber){
        return visa.isValidCard(cardNumber);
    }

}
