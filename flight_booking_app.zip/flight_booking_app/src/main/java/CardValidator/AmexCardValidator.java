package CardValidator;

import FlightModels.InputFile;
import FlightValidators.validators;

import java.io.IOException;

public class AmexCardValidator extends CreditCardValidator{


    @Override
    public boolean isValidCard(String cardNumber) {
        String card = cardNumber;
        if (card.length() == 15  && card.charAt(0) == '3' &&
                (card.charAt(1)=='4' || card.charAt(1)=='7' )) {
                 System.out.println("It is a Valid Amex Card");
                return true;
        }
        else{
            System.out.println("It is not a Valid card");
            return false;
        }

    }

}
