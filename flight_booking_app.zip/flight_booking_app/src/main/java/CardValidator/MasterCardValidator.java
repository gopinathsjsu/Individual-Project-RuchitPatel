package CardValidator;

public class MasterCardValidator extends CreditCardValidator{

    @Override
    public boolean isValidCard(String cardNumber){
        String card = cardNumber;
        if (card.length() == 16  && card.charAt(0) == '5' &&
                Character.getNumericValue(card.charAt(1))>=1 && Character.getNumericValue(card.charAt(1))<=5) {
            System.out.println("It is a valid Master Card");
            return true;
        }
        else{
            return nextCardValidator.isValidCard(cardNumber);
        }
    }

}