package FlightModels;

import Flighthelper.ReadCSVintoJSON;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.*;

public class FlightStaticDB {

    Map<Integer,Flight> flightInventory = new HashMap<>();
    final static String path = System.getProperty("user.dir")+"/src/main/java/Resources";
    ArrayList<InputFile> bookingList = new ArrayList<>();

    public FlightStaticDB(){
        //No argument constructor
    }

     public  void setFlightInventory(String csvFile){

        List<Map<?,?>> list = ReadCSVintoJSON.readCsvToJson(path+"/"+csvFile);
        Flight flight = new Flight();
        int count = 1;
        //set the flight objects .
        for(int i = 0 ; i<list.size();i++){
            final ObjectMapper mapper = new ObjectMapper();
            flight = mapper.convertValue(list.get(i), Flight.class);
            flightInventory.put(count,flight);
            count++;
        }
    }


    public Map<Integer, Flight> getFlightInventory(){

        return flightInventory;
    }


}
