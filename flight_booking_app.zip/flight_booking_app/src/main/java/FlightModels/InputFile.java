package FlightModels;

public class InputFile {
    String bookingName;
    String flightNumber;
    String seatCategory;
    int numberOfSeats;
    String paymentCardNumber;

    public InputFile(String BookingName, String flightNumber,String seatCategory ,  int numberOfSeats, String paymentCardNumber ){
        this.bookingName = BookingName;
        this.flightNumber = flightNumber;
        this.seatCategory = seatCategory;
        this.numberOfSeats = numberOfSeats;
        this.paymentCardNumber = paymentCardNumber;

    }

    public InputFile() {
        //No argument constructor.
    }

    public String getBookingName(){
        return this.bookingName;
    }

    public void setBookingName(String bookingName){
        this.bookingName = bookingName;

    }

    public String getFlightNumber(){
        return this.flightNumber;
    }

    public void setFlightNumber(String flightNumber){
        this.flightNumber = flightNumber;

    }

    public String getSeatCategory(){
        return this.seatCategory;
    }

    public void setSeatCategory(String seatCategory){
        this.seatCategory = seatCategory;

    }
    public int getNumberOfSeats(){
        return this.numberOfSeats;
    }

    public void setNumberOfSeats(int numberOfSeats){
        this.numberOfSeats = numberOfSeats;
    }

    public void setPaymentCardNumber(String paymentCardNumber){
        this.paymentCardNumber = paymentCardNumber;

    }

    public String getPaymentCardNumber(){
        return this.paymentCardNumber;
    }




}
