package test;

import CardValidator.*;
import FlightModels.FlightStaticDB;
import FlightModels.InputFile;
import FlightValidators.CalculatePrice;
import FlightValidators.ReadInputFilesCSV;
import FlightValidators.checkFlightExist;
import FlightValidators.checkSeatAvailability;
import Flighthelper.PropertiesReader;
import OutputFactory.CSVWrite;
import OutputFactory.ErrorReason;
import OutputFactory.Output;
import com.fasterxml.jackson.databind.ObjectMapper;


import java.io.IOException;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class RunClient {


    public static void main(String[] args) throws IOException {
        System.out.println("This is the flight booking app");
        CSVWrite writeTocsv = new CSVWrite();
      try {
          //Read Input CSV File and Flight use JVM parameters
          PropertiesReader pr = new PropertiesReader();
          pr.loadPropertiesFile();
          PropValue.MainConfig = pr.prop;
          if (args.length > 0) {
              PropValue.MainConfig.setProperty("INPUTFILENAME", args[0]);
              PropValue.MainConfig.setProperty("FLIGHTAPPDB", args[1]);
              PropValue.MainConfig.setProperty("OUTPUTFILENAME", args[2]);
              PropValue.MainConfig.setProperty("ERRORFILENAME", args[3]);

          }
          PropValue.outputRecord = new LinkedList<>();
          executeApp();
          //write to an output file.
          writeTocsv.addRecordToCSV(PropValue.outputRecord);
          //write to an error file
          writeTocsv.addRecordToErrorFile(PropValue.errorRecord);
      }
        catch(Exception e){
            e.printStackTrace();
          }
    }

    public static void executeApp() throws IOException {
        ReadInputFilesCSV csv = new ReadInputFilesCSV();
        InputFile bookingRecord = new InputFile();
        checkFlightExist checkflight = new checkFlightExist();
        checkSeatAvailability checkseat = new checkSeatAvailability();
        FlightStaticDB dbInstance = new FlightStaticDB();
        CardHandlerChain cardChain = new CardHandlerChain();
        CalculatePrice pr = new CalculatePrice();
        Output write = new Output();
        ErrorReason error = new ErrorReason();
        double finalPrice = 0.00;
        ObjectMapper mapper;
        String path = System.getProperty("user.dir")+"/src/main/java/InputFiles/";
        String csvFile = PropValue.MainConfig.getProperty("INPUTFILENAME");
        List<Map<?,?>> bookinglist =  csv.convertCsvToMap(path+csvFile);
        String errorReason = null;

        //set the flight inventory and payment card
        dbInstance.setFlightInventory(PropValue.MainConfig.getProperty("FLIGHTAPPDB"));
        for(int i = 0 ; i<bookinglist.size();i++) {
            //process each row of CSV now and deserialize into InputFile Class.
            mapper = new ObjectMapper();
            bookingRecord = mapper.convertValue(bookinglist.get(i), InputFile.class);

            //verify valid Details
            if (checkflight.validate(bookingRecord, dbInstance)) {
                //verify seat availability
                if (checkseat.validate(bookingRecord, dbInstance)) {
                    //calculate price
                    finalPrice = pr.calculateTotalPrice(bookingRecord, dbInstance);
                } else {
                    //write to  error file invalid seats
                    errorReason = "Not enough Seat available, re-enter the Seat Requested";
                    error.writeToAFile(bookingRecord.getBookingName(),bookingRecord.getFlightNumber(), errorReason,
                            Integer.toString(bookingRecord.getNumberOfSeats()) ,Double.toString(finalPrice));
                    continue;
                }

             } else {
                //add record for Invalid flight number in output.txt
                errorReason = "Invalid Flight Number";
                error.writeToAFile(bookingRecord.getBookingName(),bookingRecord.getFlightNumber(), errorReason,
                        Integer.toString(bookingRecord.getNumberOfSeats()) ,Double.toString(finalPrice));
                continue;

            }

            //Card validation

             if(cardChain.cardValidation(bookingRecord.getPaymentCardNumber())){
                 //modify the seat availability
                 checkseat.updateSeatAvailability();
                 //add processed record to List<String[]>
                 write.writeToAFile(bookingRecord.getBookingName(),bookingRecord.getFlightNumber(), bookingRecord.getSeatCategory(),
                         Integer.toString(bookingRecord.getNumberOfSeats()) ,Double.toString(finalPrice));
             }
             else{
                 //write to Output.txt file
                 errorReason = "Invalid Card Number, Please Re-enter the card";
                 error.writeToAFile(bookingRecord.getBookingName(),bookingRecord.getFlightNumber(), errorReason,
                         Integer.toString(bookingRecord.getNumberOfSeats()) ,Double.toString(finalPrice));
             }

        }
    }
}
