package test;

import java.util.ArrayList;
import java.util.LinkedList;

import java.util.List;
import java.util.Properties;


public class PropValue {

    public static Properties MainConfig = null;
    public static LinkedList<String[]> outputRecord = new LinkedList<>();
    public static List<String> errorRecord = new ArrayList<>();

}
