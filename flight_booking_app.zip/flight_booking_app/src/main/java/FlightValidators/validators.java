package FlightValidators;
import FlightModels.FlightStaticDB;
import FlightModels.InputFile;
import java.io.IOException;


public interface validators {


    boolean validate(InputFile inputFile , FlightStaticDB dbInstance)throws IOException;

}
