package FlightValidators;

import com.fasterxml.jackson.databind.MappingIterator;
import com.fasterxml.jackson.dataformat.csv.CsvMapper;
import com.fasterxml.jackson.dataformat.csv.CsvSchema;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ReadInputFilesCSV {


    public ReadInputFilesCSV() {
        //No argument constructor
    }

    public List<Map<?, ?>> convertCsvToMap(String csvFile) throws IOException {

        File read = new File(csvFile);
        List<Map<?,?>> inputFile = new ArrayList<>();
        try {
            CsvSchema csv = CsvSchema.emptySchema().withHeader();
            CsvMapper csvMapper = new CsvMapper();
            MappingIterator<Map<?,?>> mappingIterator =  csvMapper.reader().forType(Map.class).with(csv).readValues(read);
            System.out.println();
            while(mappingIterator.hasNext()){
                inputFile.add(mappingIterator.next());
            }
        } catch(Exception e) {
            e.printStackTrace();
        }
        System.out.println(inputFile);
        return inputFile;
   }



}
