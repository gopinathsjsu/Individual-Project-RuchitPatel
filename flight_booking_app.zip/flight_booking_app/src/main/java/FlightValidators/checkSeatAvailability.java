package FlightValidators;

import FlightModels.Flight;
import FlightModels.FlightStaticDB;
import FlightModels.InputFile;


import java.util.HashMap;
import java.util.Map;

public class checkSeatAvailability implements validators {

    String flightNumber = null;
    int seatRequested = 0;
    String category = null;
    Map<Integer, Flight> flightInventory = new HashMap<>();
    int flightKey = 0;
    int seatAvailable = 0;

    @Override
    public boolean validate(InputFile inputFile, FlightStaticDB dbInstance )  {
        //check seat availability
        flightNumber = inputFile.getFlightNumber();
        seatRequested = inputFile.getNumberOfSeats();
        category = inputFile.getSeatCategory();

        flightInventory =  dbInstance.getFlightInventory();
        for (Map.Entry<Integer,Flight> entry : flightInventory.entrySet()){
            if(entry.getValue().getFlightNumber().equalsIgnoreCase(flightNumber)
                    && entry.getValue().getCategory().equalsIgnoreCase(category)){
                flightKey = entry.getKey();
                seatAvailable = entry.getValue().getSeatAvailable();

                if(seatRequested<=seatAvailable){
                    System.out.println("Valid Seat Available"+" "+seatAvailable+" "+
                            "for the flight"+ " "+inputFile.getFlightNumber()+" "+"in category"+
                            inputFile.getSeatCategory());
                    return true;
                }
            }
        }
        System.out.println("Invalid Seat number requested");
       return false;
      }

      public void updateSeatAvailability(){
          flightInventory.get(flightKey).setSeatAvailable(seatAvailable-seatRequested);
          System.out.println("Seat Available now"+" "+flightInventory.get(flightKey).getSeatAvailable());
      }



}
