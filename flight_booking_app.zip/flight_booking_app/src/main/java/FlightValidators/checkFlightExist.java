package FlightValidators;

import FlightModels.Flight;
import FlightModels.FlightStaticDB;
import FlightModels.InputFile;
import java.util.Map;

public class checkFlightExist implements validators {


    @Override
    public boolean validate(InputFile inputFile, FlightStaticDB dbInstance) {
        String flightNumber = inputFile.getFlightNumber();
        //check from the Flight staticDb if flight number exist

        Map<Integer, Flight> flightInventory = dbInstance.getFlightInventory();
        for (Map.Entry<Integer, Flight> entry : flightInventory.entrySet()) {
            if (entry.getValue().getFlightNumber().equalsIgnoreCase(flightNumber)) {
                System.out.println("Valid Flight number" + " " + entry.getValue().getFlightNumber());
                return true;
            }
        }
        System.out.println("This is not a Valid Flight Number"+" "+flightNumber);
        return false;
    }
}
