package FlightValidators;

import FlightModels.Flight;
import FlightModels.FlightStaticDB;
import FlightModels.InputFile;

import java.util.Map;

public class CalculatePrice {

    public  double calculateTotalPrice(InputFile inputfile, FlightStaticDB dbInstance) {

        String flightNumber = inputfile.getFlightNumber();
        int seatAvailability = inputfile.getNumberOfSeats();
        String category = inputfile.getSeatCategory();

        Map<Integer, Flight> flightInventory = dbInstance.getFlightInventory();
        for (Map.Entry<Integer, Flight> entry : flightInventory.entrySet()) {
            if (entry.getValue().getFlightNumber().equalsIgnoreCase(flightNumber)
                    && entry.getValue().getCategory().equalsIgnoreCase(category)) {
                double finalPrice = seatAvailability * entry.getValue().getPrice();
                System.out.println("Total Price for the booking"+" "+finalPrice);
                return finalPrice;
            }
        }
        return 0.0;
    }
}
