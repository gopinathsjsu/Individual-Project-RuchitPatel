package OutputFactory;

public interface Writer {
    public void writeToAFile(String bookingName ,
                      String flightNumber , String category , String numberOfSeats ,String finalPrice );

}
