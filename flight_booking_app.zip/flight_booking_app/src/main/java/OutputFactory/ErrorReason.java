package OutputFactory;

import test.PropValue;

public class ErrorReason implements Writer{



    @Override
    public void writeToAFile(String bookingName, String flightNumber, String category, String numberOfSeats, String finalPrice) {
        String reason = category;
        String content = "Please enter correct details for"+"  "+bookingName+":"+"  "+ reason;
        PropValue.errorRecord.add(content);
    }
}
