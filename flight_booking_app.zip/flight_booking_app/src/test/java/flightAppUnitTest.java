import CardValidator.CardHandlerChain;
import FlightModels.Flight;
import FlightModels.FlightStaticDB;
import FlightModels.InputFile;
import FlightValidators.CalculatePrice;
import FlightValidators.ReadInputFilesCSV;
import FlightValidators.checkFlightExist;
import FlightValidators.checkSeatAvailability;
import Flighthelper.PropertiesReader;
import OutputFactory.CSVWrite;
import OutputFactory.ErrorReason;
import OutputFactory.Output;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Before;
import org.junit.Test;
import test.PropValue;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class flightAppUnitTest {
    ReadInputFilesCSV csv;
    String inputFile ;
    String flightDbFile;
    ObjectMapper  mapper ;
    List<Map<?,?>> bookingList = new ArrayList<>();
    FlightStaticDB dbInstance;
    checkSeatAvailability check;

    checkFlightExist checkFlight;

    CalculatePrice price;

    InputFile testRecord;

    double finalPrice = 0.0;
    PropertiesReader pr;

    @Before
    public void setup() throws IOException {
        csv = new ReadInputFilesCSV();
        dbInstance =  new FlightStaticDB();
        inputFile = System.getProperty("user.dir")+"/src/main/java/InputFiles/Input2.csv";
        bookingList =  csv.convertCsvToMap(inputFile);
        mapper = new ObjectMapper();
        flightDbFile = "flights.csv";
        //set Flight inventory
        dbInstance.setFlightInventory(flightDbFile);
        dbInstance.getFlightInventory();
        testRecord = mapper.convertValue(bookingList.get(0), InputFile.class);
         pr = new PropertiesReader();
        pr.loadPropertiesFile();
        PropValue.MainConfig = pr.prop;
        PropValue.outputRecord = new LinkedList<>();

    }


    public flightAppUnitTest() throws IOException {
        //no agrument constructor
    }

    @Test
    public void creditCardValidity(){
        CardHandlerChain chainHandler = new CardHandlerChain();
        boolean validity = chainHandler.cardValidation("5410000000000000");
        System.out.println(validity);
        validity = chainHandler.cardValidation("4120000000000");
        System.out.println(validity);
        validity = chainHandler.cardValidation("6011000000000000");
        System.out.println(validity);
        validity = chainHandler.cardValidation("1234561323130");
        System.out.println(validity);
        validity = chainHandler.cardValidation("4120077000000");
        System.out.println(validity);
        validity = chainHandler.cardValidation("12343234534534543456");
        System.out.println(validity);
    }

    @Test
    public void validFlightNumber(){
        checkFlight = new checkFlightExist();
        checkFlight.validate(testRecord,dbInstance);
    }

    @Test
    public void invalidFlightNumber(){
        InputFile testRecord = mapper.convertValue(bookingList.get(1), InputFile.class);
        checkFlight = new checkFlightExist();
        checkFlight.validate(testRecord,dbInstance);
    }

    @Test
    public void checkSeatAvailability(){
        check = new checkSeatAvailability();
        boolean valid = check.validate(testRecord,dbInstance);
        if (valid)
        check.updateSeatAvailability();

    }


    @Test
    public void calculateFinalPrice(){
        price = new CalculatePrice();
        finalPrice= price.calculateTotalPrice(testRecord,dbInstance);
    }


    @Test
    public void writeToAFile() throws IOException {
        String errorReason;
        CSVWrite writeTocsv = new CSVWrite();
        ErrorReason error = new ErrorReason();
        Output outputTocsv = new Output();
        checkFlight = new checkFlightExist();
        if (checkFlight.validate(testRecord, dbInstance)) {
            check = new checkSeatAvailability();
            if (check.validate(testRecord, dbInstance)) {
                if (checkCreditCard(testRecord.getPaymentCardNumber())) {
                    price = new CalculatePrice();
                    finalPrice = price.calculateTotalPrice(testRecord, dbInstance);
                    check.updateSeatAvailability();
                    outputTocsv.writeToAFile(testRecord.getBookingName(), testRecord.getFlightNumber(), testRecord.getSeatCategory(),
                            Integer.toString(testRecord.getNumberOfSeats()), Double.toString(finalPrice));
                } else {
                    errorReason = "Invalid Card Number, Please Re-enter the card";
                    error.writeToAFile(testRecord.getBookingName(), testRecord.getFlightNumber(), errorReason,
                            Integer.toString(testRecord.getNumberOfSeats()), Double.toString(finalPrice));
                }
            }
                else{
                    errorReason = "Invalid Seat Requested";
                    error.writeToAFile(testRecord.getBookingName(), testRecord.getFlightNumber(), errorReason,
                            Integer.toString(testRecord.getNumberOfSeats()), Double.toString(finalPrice));
                }

        } else {
            errorReason = "Invalid Flight Number";
            error.writeToAFile(testRecord.getBookingName(), testRecord.getFlightNumber(), errorReason,
                    Integer.toString(testRecord.getNumberOfSeats()), Double.toString(finalPrice));
          }
            writeTocsv.addRecordToCSV(PropValue.outputRecord);
            writeTocsv.addRecordToErrorFile(PropValue.errorRecord);

        }

    private boolean checkCreditCard(String creditCardNumber){
        CardHandlerChain chainHandler = new CardHandlerChain();
        boolean validity = chainHandler.cardValidation(creditCardNumber);
        return validity;
    }



}
