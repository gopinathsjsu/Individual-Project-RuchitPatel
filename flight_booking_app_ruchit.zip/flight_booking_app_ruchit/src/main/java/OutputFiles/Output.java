package OutputFiles;

import test.PropValue;

public class Output implements Writer {

    @Override
    public void writeToFile(String bookingName ,
                             String flightNumber , String category , String numberOfSeats ,String finalPrice ) {

        String[] record = {bookingName ,flightNumber, category, numberOfSeats, finalPrice};
        PropValue.outputRecord.add(record);
    }


    }

