package OutputFiles;

public interface Writer {
    public void writeToFile(String bookingName ,
                      String flightNumber , String category , String numberOfSeats ,String finalPrice );

}
