# individual-project-supriyameduri9

##individual-project-supriyameduri9 created by GitHub Classroom

### Command to Run the project 

mvn compile exec:java -Dexec.mainClass="com.cmpe202.individualproject.main.App" -Dexec.args="/Users/supriyameduri/Documents/creditcard/src/test/java/sampleFiles/json_input.json /Users/supriyameduri/Documents/creditcard/src/test/java/sampleFiles/json_output.json"

### Command to Run tests:
mvn test

### Command to recompile the project:
mvn clean

#### Refer "class diagram.png" file for class diagram 
#### Refer "part1+part2.docx" file for part1 and part2 solutions 


