package com.cmpe202.individualproject.handlers;

import com.cmpe202.individualproject.main.CreditCardEntry;

public interface CreditCardHandler {
    public String checkCreditCardType(CreditCardEntry creditCardEntry);
}
